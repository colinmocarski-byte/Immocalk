# ImmoCalc – Schnellrechner (ZIP)
## Ordner
- `server/` – Node.js API (Scraper + Endpunkte)
- `web/` – Frontend (HTML/CSS/JS)

## Lokal starten (PC/Mac)
```
cd server
npm i
npm run start   # http://localhost:4000
```
Dann `web/index.html` im Browser öffnen.

## Replit (geht am iPhone im Browser)
1. replit.com → New Repl → Node.js
2. Dateien aus `server/` hochladen → Run → URL kopieren
3. In `web/app.js` oben `API` auf die Replit-URL setzen
4. Neues Repl "Static" (oder Netlify/Vercel) → Dateien aus `web/` hochladen
